# Project Structure

```
├── app.py                 # Main Flask application
├── static/
│   ├── css/
│   │   └── style.css     # Main stylesheet
│   ├── images/           # SVG illustrations
│   │   ├── about-hero.svg
│   │   ├── learning-hero.svg
│   │   ├── lessons-hero.svg
│   │   └── resources-hero.svg
│   └── js/
│       └── main.js       # JavaScript functionality
└── templates/            # Jinja2 templates
    ├── about.html
    ├── base.html        # Base template
    ├── contact.html
    ├── home.html
    ├── lessons.html
    └── resources.html
```

## Main Application Files:

1. `app.py` - Flask application setup and routes
2. `static/css/style.css` - Styling and animations
3. `templates/base.html` - Base template with common elements
4. `templates/home.html` - Landing page
5. `static/js/main.js` - Client-side functionality

Each file's contents follow below.
