# Educational Platform Source Code

## Project Structure
```
├── app.py                 # Main Flask application
├── static/
│   ├── css/
│   │   └── style.css     # Main stylesheet
│   ├── images/           # SVG illustrations
│   │   ├── about-hero.svg
│   │   ├── learning-hero.svg
│   │   ├── lessons-hero.svg
│   │   └── resources-hero.svg
│   └── js/
│       └── main.js       # JavaScript functionality
└── templates/            # Jinja2 templates
    ├── about.html
    ├── base.html        # Base template
    ├── contact.html
    ├── home.html
    ├── lessons.html
    └── resources.html
```

## File Contents

### app.py
```python
import os
from flask import Flask, render_template, request, flash, redirect, url_for
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/lessons')
def lessons():
    return render_template('lessons.html')

@app.route('/resources')
def resources():
    return render_template('resources.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
```

### static/css/style.css
```css
:root {
    --primary-color: #4361ee;
    --secondary-color: #3f37c9;
    --text-color: #2b2d42;
    --light-bg: #f8f9fa;
    --success-color: #4cc9f0;
}

body {
    font-family: 'Inter', sans-serif;
    color: var(--text-color);
    line-height: 1.6;
}

/* Navbar */
.navbar {
    background-color: white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 1rem 0;
}

.navbar-brand {
    font-weight: 700;
    color: var(--primary-color);
    font-size: 1.5rem;
}

/* Hero Section */
.hero {
    background: linear-gradient(135deg, #ffffff 0%, var(--light-bg) 100%);
    position: relative;
    overflow: hidden;
}

[... Rest of style.css content ...]
```

### static/js/main.js
```javascript
document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const contactForm = document.querySelector('#contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            const email = document.querySelector('#email');
            const message = document.querySelector('#message');

            if (!email.value || !message.value) {
                e.preventDefault();
                alert('Please fill in all required fields');
            }
        });
    }

    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
```

### templates/base.html
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Join Our Waitlist - Early Access Coming Soon{% endblock %}</title>
    <meta name="description" content="Join our waitlist to get early access to our revolutionary learning platform">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    [... Rest of base.html content ...]
</body>
</html>
```

[... Contents of other template files and SVG files ...]

## Requirements
```
flask
flask-sqlalchemy
gunicorn
psycopg2-binary
email-validator
```

## Setup Instructions
1. Install the required packages using pip:
   ```
   pip install -r requirements.txt
   ```

2. Set the environment variables:
   ```
   export SESSION_SECRET=your_secret_key
   ```

3. Run the application:
   ```
   python app.py
   ```

The application will be available at `http://localhost:5000`
