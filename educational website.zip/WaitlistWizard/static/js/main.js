document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const contactForm = document.querySelector('#contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            const email = document.querySelector('#email');
            const message = document.querySelector('#message');

            if (!email.value || !message.value) {
                e.preventDefault();
                alert('Please fill in all required fields');
            }
        });
    }

    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});